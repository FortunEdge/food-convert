var recipeIng, recipeServ, recipeTemp, recipeInst, recipeAmnt, recipeNam;
var unitList = ["Grams", "Grams - Fine Powder", "Grams - Granular", "Grams - Grains", "Grams - Liquid Solids", "Liters", "Milliliters", "Centimeters", "Millimeters", "Ounces", "Pounds", "Teaspoons", "Tablespoons", "Cups", "Quarts", "Pints", "Gallons"];

$(document).ready(function() {
    chieght();
    loadDropDowns();
})

function chieght() {
    let h = $('body').height();
    document.getElementById('page_cont').style.height = h-60 + "px";
}

//////////////////////////////////////////////
//Saving/////////////////////////////////////
////////////////////////////////////////////

/**function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

function handleCookie() {
    
}**/


function loadStorage() {

}

function setStorage() {

}

function checkStorage() {

}

//Localstorage.recipeing 
//Localstorage.recipeserv
//Localstorage.recipetemp
//Localstorage.recipeinst
//Localstorage.recipeamnt
//Localstorage.recipename


////////////////////////////////////////////
//Page Handling////////////////////////////
//////////////////////////////////////////

function changePage(pagename, title) {
    $('#page_cont').fadeOut(500, function() {
        $('#page_cont').html(pagename);
        $('#page_cont').fadeIn(500);
    });
    changeTitle(title);
}

function changeTitle(title) {
    if(title == "none") {
        $('div.title_top').html("");
    }
    else {
        $('div.title_top').html(title);
    }
}

function home() {
    // Check var set in welcome function
}

function Menu(el) {
    $('div#body').toggleClass('showmenu');
    $('div#bodyo').toggleClass('showmenu');
    $('ul#opt_but_cont').toggleClass('menuopen');
    $(el).blur();
}

function welcome() {
    // Check cookies first, then storage
}

///////////////////////////////////////////
//Drop-Downs//////////////////////////////
/////////////////////////////////////////

function loadDropDowns() {
    if($('select.ing')) {
        let l = unitList.length;
        let html = '';
        for(i=0; i<l; i++) {
            html += '<option value="' + unitList[i] + '">' + unitList[i] + '</option>'
        }
        let drops = $('select.ing');
        for(i=0; i<drops.length; i++) {
            if(drops[i].value) {
                
            }
            else{drops[i].innerHTML = html;}
        }
    }
}

function optChoose(el) {
    let value = el.innerHTML;
    let opt_box = $(el).parent().parent();
    opt_box.prev().html(value);
    opt_box.parent().data('value',value);
    opt_box.slideUp();
}

function optOut(el) {
    $(el).parent().slideUp();
}

function optIn(el) {
    $(el).prev().slideDown();
}

function optGet() {
    let dropdowns = $('div.select');
    for(i=0; i<dropdowns.length; i++) {
        dropdowns[i] = $(dropdowns[i]).data('value');
    }
    return dropdowns;
}

/////////////////////////////////
//Ingredients///////////////////
///////////////////////////////

function addIng(el) {
    $('div#ing_cont').append(ing_opt);
    loadDropDowns();
    $(el).blur();
}

function deleteIng(el) {
    $(el).parent().remove();
}

/////////////////////////////////
//Temperatures//////////////////
///////////////////////////////

function addTemp(el) {
    $('div#ing_cont').append(temp_opt);
    loadDropDowns();
    $(el).blur();
}